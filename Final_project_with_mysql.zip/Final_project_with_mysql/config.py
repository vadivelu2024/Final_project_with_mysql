# Database configuration
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'  # Default XAMPP MySQL username
MYSQL_PASSWORD = ''  # Default XAMPP MySQL password (empty)
MYSQL_DB = 'parkeasy_db'
MYSQL_CURSORCLASS = 'DictCursor'
