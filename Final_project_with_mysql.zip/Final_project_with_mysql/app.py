from flask import Flask, render_template, url_for, request, flash, redirect, jsonify, make_response
from flask_mysqldb import MySQL
import pymysql
from datetime import datetime
import config
import csv
from io import StringIO

app = Flask(__name__)
app.secret_key = 'parking_app_secret_key'

# MySQL Configuration
app.config['MYSQL_HOST'] = config.MYSQL_HOST
app.config['MYSQL_USER'] = config.MYSQL_USER
app.config['MYSQL_PASSWORD'] = config.MYSQL_PASSWORD
app.config['MYSQL_DB'] = config.MYSQL_DB
app.config['MYSQL_CURSORCLASS'] = config.MYSQL_CURSORCLASS

mysql = MySQL(app)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/services")
def services():
    return render_template("services.html")

@app.route("/find-parking")
def find_parking():
    location = request.args.get('location', '')
    
    if location:
        google_maps_url = f"https://www.google.com/maps/search/parking+near+{location.replace(' ', '+')}"
    else:
        google_maps_url = "https://www.google.com/maps/search/parking+near+me"
    
    return redirect(google_maps_url)

@app.route("/careers")
def careers():
    return render_template("careers.html")

@app.route("/contact", methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        print("Form submitted!")  # Debug print
        try:
            # Get form data
            name = request.form.get('name')
            email = request.form.get('email')
            parking_type = request.form.get('parking_type')
            message = request.form.get('message')
            
            print(f"Form data: name={name}, email={email}, parking_type={parking_type}, message={message[:50] if message else None}...")  # Debug print
            
            # Validate form data
            if not all([name, email, parking_type, message]):
                print("Validation failed - missing fields")  # Debug print
                flash('Please fill in all required fields.', 'error')
                return render_template("contact.html")
            
            # Insert data into MySQL database
            cursor = mysql.connection.cursor()
            cursor.execute(
                "INSERT INTO contacts (name, email, parking_type, message) VALUES (%s, %s, %s, %s)",
                (name, email, parking_type, message)
            )
            mysql.connection.commit()
            cursor.close()
            
            print("Data inserted successfully!")  # Debug print
            flash('✅ Data submitted successfully! Your message has been saved to our database. We will get back to you soon.', 'success')
            return redirect(url_for('contact'))
            
        except Exception as e:
            print(f"Error occurred: {e}")  # Debug print
            flash('An error occurred while submitting your message. Please try again.', 'error')
            print(f"Database error: {e}")  # Log error for debugging
            
    return render_template("contact.html")

@app.route("/admin/contacts")
def admin_contacts():
    """Admin route to view all contact submissions"""
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM contacts ORDER BY created_at DESC")
        contacts = cursor.fetchall()
        cursor.close()
        return render_template("admin_contacts.html", contacts=contacts)
    except Exception as e:
        flash(f"Database error: {e}", 'error')
        return render_template("admin_contacts.html", contacts=[])

@app.route("/admin/export_contacts_csv")
def export_contacts_csv():
    """Export contact submissions to CSV file"""
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM contacts ORDER BY created_at DESC")
        contacts = cursor.fetchall()
        cursor.close()
        
        # Create CSV content with proper encoding
        output = StringIO()
        writer = csv.writer(output, quoting=csv.QUOTE_ALL)
        
        # Write header row
        writer.writerow(['ID', 'Name', 'Email', 'Parking Type', 'Message', 'Verified', 'Submitted Date', 'Submitted Time'])
        
        # Write data rows
        for contact in contacts:
            # Format the date and time separately for better CSV compatibility
            if contact['created_at']:
                date_part = contact['created_at'].strftime('%Y-%m-%d')
                time_part = contact['created_at'].strftime('%H:%M:%S')
            else:
                date_part = ''
                time_part = ''
            
            # Handle verified attribute
            verified_status = 'Yes' if contact['verified'] else 'No'
            
            # Clean message text to prevent CSV issues
            message_text = str(contact['message']).replace('\n', ' ').replace('\r', ' ') if contact['message'] else ''
            
            writer.writerow([
                str(contact['id']),
                str(contact['name']),
                str(contact['email']),
                str(contact['parking_type']),
                message_text,
                verified_status,
                date_part,
                time_part
            ])
        
        # Create response with UTF-8 BOM for Excel compatibility
        csv_content = '\ufeff' + output.getvalue()  # Add BOM for Excel
        response = make_response(csv_content)
        response.headers['Content-Type'] = 'text/csv; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename=parkeasy_contacts_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        
        return response
        
    except Exception as e:
        flash(f'Error exporting contacts: {e}', 'error')
        return redirect(url_for('admin_contacts'))

@app.route("/admin/reports")
def admin_reports():
    """Admin reports with analytics and charts"""
    try:
        cursor = mysql.connection.cursor()
        
        # Get all contacts for analysis
        cursor.execute("SELECT * FROM contacts ORDER BY created_at DESC")
        contacts = cursor.fetchall()
        
        # Generate statistics
        total_contacts = len(contacts)
        verified_contacts = len([c for c in contacts if c['verified']])
        pending_contacts = total_contacts - verified_contacts
        
        # Parking type distribution
        parking_types = {}
        for contact in contacts:
            ptype = contact['parking_type']
            parking_types[ptype] = parking_types.get(ptype, 0) + 1
        
        # Monthly submission trends (last 6 months)
        from collections import defaultdict
        monthly_data = defaultdict(int)
        for contact in contacts:
            if contact['created_at']:
                month_key = contact['created_at'].strftime('%Y-%m')
                monthly_data[month_key] += 1
        
        # Sort monthly data
        sorted_months = sorted(monthly_data.items())
        
        # Daily submissions (last 7 days)
        daily_data = defaultdict(int)
        for contact in contacts:
            if contact['created_at']:
                # Only include last 7 days
                days_diff = (datetime.now() - contact['created_at']).days
                if days_diff <= 7:
                    day_key = contact['created_at'].strftime('%Y-%m-%d')
                    daily_data[day_key] += 1
        
        sorted_days = sorted(daily_data.items())
        
        cursor.close()
        
        return render_template("admin_reports.html", 
                             contacts=contacts,
                             total_contacts=total_contacts,
                             verified_contacts=verified_contacts,
                             pending_contacts=pending_contacts,
                             parking_types=parking_types,
                             monthly_data=sorted_months,
                             daily_data=sorted_days)
        
    except Exception as e:
        flash(f'Error generating reports: {e}', 'error')
        return redirect(url_for('admin_contacts'))

@app.route("/admin/verify_contact/<int:contact_id>", methods=['POST'])
def verify_contact(contact_id):
    """Mark a contact submission as verified"""
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("UPDATE contacts SET verified = TRUE WHERE id = %s", (contact_id,))
        mysql.connection.commit()
        cursor.close()
        
        flash('✅ Contact submission verified successfully!', 'success')
        return redirect(url_for('admin_contacts'))
            
    except Exception as e:
        flash(f'Error verifying contact: {e}', 'error')
        return redirect(url_for('admin_contacts'))

@app.route("/admin/delete_contact/<int:contact_id>", methods=['POST'])
def delete_contact(contact_id):
    """Delete a contact submission"""
    try:
        cursor = mysql.connection.cursor()
        result = cursor.execute("DELETE FROM contacts WHERE id = %s", (contact_id,))
        mysql.connection.commit()
        cursor.close()
        
        flash('🗑️ Contact submission deleted successfully!', 'success')
        return redirect(url_for('admin_contacts'))
            
    except Exception as e:
        flash(f'Error deleting contact: {e}', 'error')
        return redirect(url_for('admin_contacts'))

@app.route("/admin/contact_details/<int:contact_id>")
def contact_details(contact_id):
    """View detailed information about a specific contact submission"""
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM contacts WHERE id = %s", (contact_id,))
        contact = cursor.fetchone()
        cursor.close()
        
        if contact:
            return render_template("contact_details.html", contact=contact)
        else:
            flash('Contact submission not found.', 'error')
            return redirect(url_for('admin_contacts'))
    except Exception as e:
        flash(f'Database error: {e}', 'error')
        return redirect(url_for('admin_contacts'))

if __name__ == "__main__":
    app.run(debug=True)